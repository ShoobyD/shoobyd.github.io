'use strict';

describe('browser build', function() {
  require('./plain');
  require('./worker');
});
