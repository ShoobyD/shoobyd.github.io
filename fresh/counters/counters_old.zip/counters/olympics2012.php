<?php

/*
 *  Description: 2012 Olympic games counter.
 *  Revised: 04/03/12
 *  Site: http://shoobyd.herobo.com
 *  Design: Samantha
 *  Author: Baruch Mustakis (a.k.a. ShoobyD)
 */

$time_diff = mktime( 0, 0, 0, 7, 27, 2012 ) - time();
header('Content-type: image/png');

if ( $time_diff > 0 ) {

	$num_days = ceil( $time_diff / 86400 );
	$num_days = str_pad( $num_days, 3, "0", STR_PAD_LEFT );
	$image = imagecreatefrompng("Olympics2012_base.png");

	// define parameters.
	$pos_x = 282;
	$pos_y = 10;
	$out_size = 2;
	$text_color = imagecolorallocate( $image, 8, 84, 181 );
	//$text_color = imagecolorallocate( $image, 232, 80, 0 ); // red.
	//$text_color = imagecolorallocate( $image, 222, 57, 0 );
	$outline_color = imagecolorallocate( $image, 255, 255, 255 );
	$shade_color = imagecolorallocate( $image, 127, 127, 127 );

	// draw shadow.
	for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
		imagestring($image, 5, $i + 1, $pos_y + $out_size + 1, $num_days, $shade_color);
	// draw outline.
	for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
		for ( $j = $pos_y - $out_size; $j < $pos_y + $out_size + 1; $j++ )
			imagestring( $image, 5, $i, $j, $num_days, $outline_color );
	// draw text.
	imagestring( $image, 5, $pos_x, $pos_y, $num_days, $text_color );

	// export image and free alloc space.
	imagepng( $image );
	imagedestroy( $image );

}

else {

	// date passed.
	$image = file_get_contents("Olympics2012_post.png");
	echo $image;

}

?>

