
<?php

$interval = new DateInterval('P2Y4DT6H8M');
echo $interval->format('%d days');

/*
$date = DateTime::createFromFormat('j-M-Y', '15-Feb-2009');
//$date = date_create_from_format( "d/m/Y", $_GET["date"] );

echo date_format( $date, 'Y-m-d' );
*/
?>

