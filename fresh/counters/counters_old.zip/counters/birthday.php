<?php

/*
 *  Description: Birthday counter.
 *  Revised: 04/03/12
 *  Site: http://shoobyd.herobo.com
 *  Design: Samantha
 *  Author: Baruch Mustakis (a.k.a. ShoobyD)
 */

$bad_date = "Error: Date must be in dd/mm format.";
//$bad_date = "Error: Impossible date entered.";
header('Content-type: image/png');

$birthday = $_GET["date"];
$day = substr( $birthday, 0, 2 );
$month = substr( $birthday, 3, 2 );

if ( strlen( $birthday ) == 5 && substr( $birthday, 2, 1 ) == "/" &&
	 is_numeric( $day ) && is_numeric( $month ) ) {

	$next = mktime( 0, 0, 0, $month, $day, date("Y") );
	$num_days = ceil( ($next - time()) / 86400 );

	if ( $num_days ) { // not today.

		$image = imagecreatefrompng("Birthday_base.png");
		if ( $next - time() < 0 ) // next year.
			$next = mktime( 0, 0, 0, $month, $day, date("Y")+1 );
		$num_days = ceil( ($next - time()) / 86400 );
		$num_days = str_pad( $num_days, 3, "0", STR_PAD_LEFT );

		// define parameters.
		$pos_x = 88;
		$pos_y = 11;
		$out_size = 2;
		$text_color = imagecolorallocate( $image, 182, 24, 57 );
		//$text_color = imagecolorallocate( $image, 145, 33, 0 );
		//$text_color = imagecolorallocate( $image, 49, 118, 0 ); // green.
		$outline_color = imagecolorallocate( $image, 255, 255, 255 );
		$shade_color = imagecolorallocate( $image, 127, 127, 127 );

		// draw shadow.
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			imagestring($image, 5, $i + 1, $pos_y + $out_size + 1, $num_days, $shade_color);
		// draw outline.
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			for ( $j = $pos_y - $out_size; $j < $pos_y + $out_size + 1; $j++ )
				imagestring($image, 5, $i, $j, $num_days, $outline_color);
		// draw text.
		imagestring( $image, 5, $pos_x, $pos_y, $num_days, $text_color );

		// export image and free alloc space.
		imagepng( $image );
		imagedestroy( $image );

	}

	else {

		// birthday today!
		$image = file_get_contents("Birthday_today.png");
		echo $image;

	}

}

else {

	// erroneous input.
	$image = @imagecreate(350, 32)
	   or die("Cannot Initialize new GD image stream");
	$bg_color = imagecolorallocate( $image, 240, 244, 248 );
	$text_color = imagecolorallocate( $image, 233, 14, 91 );
	imagestring( $image, 5, 16, 8, $bad_date, $text_color );
	imagepng( $image );
	imagedestroy( $image );

}

?>

