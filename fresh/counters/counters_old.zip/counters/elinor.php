<?php
header("Content-Type: text/html; charset=UTF-8");
echo '<div dir="rtl" style="text-align:center">';
$str1 = "שנת הלימודים מתחילה בעוד";
$str2 = "ימים.";
$str3 = "שנת הלימודים החלה!";

$time_diff = mktime( 0, 0, 0, 10, 21, 2012) - time();

if ( $time_diff > 0 ) {
	$num_days = ceil( $time_diff/86400 );
	echo "$str1 <span style='color: red;'>$num_days</span> $str2";
}
else echo $str3;

echo "</div>";

?>

