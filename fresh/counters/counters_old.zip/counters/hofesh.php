<?php

/*
 *  Description: Vacation counter.
 *  Revised: 04/03/12
 *  Site: http://shoobyd.herobo.com
 *  Design: Samantha
 *  Author: Baruch Mustakis (a.k.a. ShoobyD)
 */

$bad_date = "Error: Date must be in dd/mm/yyyy format.";
//$bad_date = "Error: Impossible date entered.";
header('Content-type: image/png');

$vacation = $_GET["date"];
$day = substr( $vacation, 0, 2 );
$month = substr( $vacation, 3, 2 );
$year = substr( $vacation, 6, 4 );

// date format check.
if ( strlen( $vacation ) == 10 &&
	 substr( $vacation, 2, 1 ) == "/" && substr( $vacation, 5, 1 ) == "/" &&
	 is_numeric( $day ) && is_numeric( $month ) && is_numeric( $year ) ) {

	$time_diff = mktime( 0, 0, 0, $month, $day, $year ) - time();

	if ( $time_diff > 0 ) {

		$num_days = ceil( $time_diff / 86400 );
		$num_days = str_pad( $num_days, 3, "0", STR_PAD_LEFT );
		$image = imagecreatefrompng("Hofesh_base.png");

		// define parameters.
		$pos_x = 163;
		$pos_y = 10;
		$out_size = 2;
		$text_color = imagecolorallocate( $image, 241, 249, 255 );
		$outline_color = imagecolorallocate( $image, 7, 85, 147 );
		$shade_color = imagecolorallocate( $image, 255, 255, 255 );

		// draw shadow.
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			imagestring($image, 5, $i + 1, $pos_y + $out_size + 1, $num_days, $shade_color);
		// draw outline.
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			for ( $j = $pos_y - $out_size; $j < $pos_y + $out_size + 1; $j++ )
				imagestring( $image, 5, $i, $j, $num_days, $outline_color );
		// draw text.
		imagestring( $image, 5, $pos_x, $pos_y, $num_days, $text_color );

		// export image and free alloc space.
		imagepng( $image );
		imagedestroy( $image );

	}

	else {

		// vacation started!
		$image = file_get_contents("Hofesh_started.png");
		echo $image;

	}

}

else {

	// erroneous input.
	$image = @imagecreate(350, 32)
	   or die("Cannot Initialize new GD image stream");
	$bg_color = imagecolorallocate( $image, 240, 244, 248 );
	$text_color = imagecolorallocate( $image, 0, 0, 0 );
	imagestring( $image, 4, 12, 8, $bad_date, $text_color );
	imagepng( $image );
	imagedestroy( $image );

}

?>

