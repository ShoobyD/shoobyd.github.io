<?php

/*
 *  Description: General functions for counters.
 *  Revised: 10/03/12
 *  Site: http://shoobyd.herobo.com
 *  Author: Baruch Mustakis (a.k.a. ShoobyD)
 *  License: This file is under the GNU General Public License (GPL).
 */


/********************
*   setting image   *
********************/
function set_image( $img, $text, $pos_x, $pos_y, $out_size, $text_color, $outline_color="", $shade_color="" ) {

	$text = str_pad( $text, 3, "0", STR_PAD_LEFT );
	$img = imagecreatefrompng( $img );

	// set colors.
	$text_color = hex_color_alloc( $img, $text_color );
	if ( $outline_color ) $outline_color = hex_color_alloc( $img, $outline_color );
	if ( $shade_color ) $shade_color = hex_color_alloc( $img, $shade_color );

	// draw shadow.
	if ( $shade_color )
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			imagestring( $img, 5, $i + 1, $pos_y + $out_size + 1, $text, $shade_color );
	// draw outline.
	if ( $outline_color )
		for ( $i = $pos_x - $out_size; $i < $pos_x + $out_size + 1; $i++ )
			for ( $j = $pos_y - $out_size; $j < $pos_y + $out_size + 1; $j++ )
				imagestring( $img, 5, $i, $j, $text, $outline_color );
	// draw text.
	imagestring( $img, 5, $pos_x, $pos_y, $text, $text_color );

	return $img;
}


/************************************
*   allocate color in hex format    *
************************************/
function hex_color_alloc( $img, $color ) {
	$r = "0x".$color{0}.$color{1};
	$g = "0x".$color{2}.$color{3};
	$b = "0x".$color{4}.$color{5};
	return imagecolorallocate( $img, $r, $g, $b );
}


/***************************
*   return error message   *
***************************/
function error_image( $msg, $msg2="", $bg_color="f0f4f8", $text_color="850e5b" ) {
	$height = ( $msg2 )? 52: 32;
	$font_size = ( max( strlen( $msg ), strlen( $msg2 ) ) > 36 )? 4: 5;
	$img = @imagecreate( 350, $height )
		 or die( "Cannot Initialize new GD image stream" );
	$bg_color = hex_color_alloc( $img, $bg_color );
	$text_color = hex_color_alloc( $img, $text_color );
	imagestring( $img, $font_size, 12, 8, $msg, $text_color );
	if ( $msg2 ) imagestring( $img, $font_size, 12, 28, $msg2, $text_color );
	imagepng( $img );
	imagedestroy( $img );
	header( "Content-type: image/png" );
	die();
}

?>
