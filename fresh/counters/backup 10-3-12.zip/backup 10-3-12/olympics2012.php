<?php

/*
 *  Description: 2012 Olympic games counter.
 *  Revised: 10/03/12
 *  Site: http://shoobyd.herobo.com
 *  Design: Samantha
 *  Author: Baruch Mustakis (a.k.a. ShoobyD)
 *  License: This file is under the GNU General Public License (GPL).
 */


// strings and sources.
include "counterz.php";
$date = "27/07/2012";
$img_base = "imgsrc/Olympics2012_base.png";
$img_default = "imgsrc/Olympics2012_started.png";


$date = date_create_from_format( "d/m/Y", $date );
$num_days = date_diff( date_create(), $date )->format( "%r%a" );
header( "Content-type: image/png" );

// date has passed.
if ( $num_days < 1 ) echo file_get_contents( $img_default );

// set image, export it and free alloc space.
else {
	// parameters: $img, $text, $pos_x, $pos_y, $out_size, $text_color, $outline_color, $shade_color.
	$img = set_image( $img_base, $num_days, 282, 10, 2, "0854b5", "ffffff", "7f7f7f" );
	imagepng( $img );
	imagedestroy( $img );
}

?>
